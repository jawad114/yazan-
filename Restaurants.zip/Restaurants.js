
// const mongoose = require("mongoose");

// const DishSchema = new mongoose.Schema({
//     name: String,
//     price: Number,
//     dishImage: String,
//     description: String,
//     extras:{
//       requiredExtras: [{
//       name: String,
//       price: Number,
//     }],
//     optionalExtras: [{
//       name: String,
//       price: Number
//     }]
//   }
    
// });


// const RestaurantsSchema = new mongoose.Schema({
//     restaurantName: { type: String, required: true },

//     picture: { type: String, required: true },
//     location: { type: String, required: true },
//     menu: [MenuCategorySchema],
//     generatedEmail: { type: String, required: true }, 
//     generatedPassword: { type: String, required: true } 
// }, {
//     collection: "restaurantInfo"
// });

// mongoose.model("RestaurantInfo", RestaurantsSchema);
// mongoose.model("DishInfo", DishSchema);


